$(document).ready(function(){
	var clipboard = new Clipboard('.cpy', {
        text: function() {
            var txt=$('p#quote').text()+"\nQuote Shared Via MyThoughts App!";
			return txt;
        }
    });
	clipboard.on('success', function(e) {
        alertA('Quote Copied Successfully To Clipboard!!',1500);
    });
	clipboard.on('error', function(e) {
        alertA('Copy Error!!',2000);
    });
    $("#share").click(function(){
        if(typeof Android !== "undefined" && Android !== null) {
            Android.share($('p#quote').text());
        }
    });
});

function alertA(txt,dur=5000) {
    $('span#alertCont').html(txt);
    $('div#alertD').show('1000');
    setTimeout(hideAlrt,+dur);
}

function hideAlrt() {
    $('div#alertD').hide('1000');
}