function JsStorage() 
	{
		if (typeof(Storage) !== "undefined") 
		{
			this.sprt=true;			   
		}
		else
		{
			this.sprt=false;
		}
		this.isAvail=function() 
		{
			  return this.sprt;
		}  
		this.setItem=function(key,val) 
		{
			try {
			  window.localStorage.setItem(key,val);
			}catch(err) {
				//Do Nothing...
			}
		}
		this.getItem=function(key) 
		{
			try {
				return window.localStorage.getItem(key);
			}catch(err) {
				//Do Nothing...
			}
		}
		this.delItem=function(key) 
		{
			try {
				window.localStorage.removeItem(key);
			}catch(err) {
				//Do Nothing...
			}
		}
	}